import java.util.Scanner;

public class SmallestValue_11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of values: ");
        int numValues = scanner.nextInt();
        int smallest = Integer.MAX_VALUE;

        for (int i = 0; i < numValues; i++) {
            System.out.print("Enter value " + (i + 1) + ": ");
            int value = scanner.nextInt();
            if (value < smallest) {
                smallest = value;
            }
        }

        System.out.println("Smallest value: " + smallest);
    }
}
