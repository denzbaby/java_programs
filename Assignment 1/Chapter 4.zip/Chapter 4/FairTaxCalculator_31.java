import java.util.Scanner;

public class FairTaxCalculator_31 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double fairTaxRate = 0.23; // 23% FairTax rate

        System.out.print("Enter your annual income: $");
        double income = scanner.nextDouble();

        System.out.print("Enter your annual expenses: $");
        double expenses = scanner.nextDouble();

        double fairTax = expenses * fairTaxRate;
        System.out.printf("Your estimated FairTax is: $%.2f%n", fairTax);
    }
}
