import java.util.Scanner;

public class GlobalWarmingQuiz_30 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int correctAnswers = 0;

        // Question 1
        System.out.println("Question 1: What is the main cause of global warming?");
        System.out.println("1. Burning of fossil fuels");
        System.out.println("2. Deforestation");
        System.out.println("3. Industrial agriculture");
        System.out.println("4. Natural climate variability");

        int answer1 = scanner.nextInt();
        if (answer1 == 1) {
            correctAnswers++;
        }

        // Question 2
        System.out.println("Question 2: What is the expected increase in global temperature by 2100?");
        System.out.println("1. 1-2°C");
        System.out.println("2. 2-4°C");
        System.out.println("3. 4-6°C");
        System.out.println("4. 6-8°C");

        int answer2 = scanner.nextInt();
        if (answer2 == 2) {
            correctAnswers++;
        }

        // Question 3
        System.out.println("Question 3: What is the main greenhouse gas responsible for global warming?");
        System.out.println("1. Carbon dioxide");
        System.out.println("2. Methane");
        System.out.println("3. Nitrous oxide");
        System.out.println("4. Ozone");

        int answer3 = scanner.nextInt();
        if (answer3 == 1) {
            correctAnswers++;
        }

        // Question 4
        System.out.println("Question 4: What is the expected impact of global warming on sea levels?");
        System.out.println("1. No change");
        System.out.println("2. Rise of 10-20 cm");
        System.out.println("3. Rise of 20-50 cm");
        System.out.println("4. Rise of 50-100 cm");

        int answer4 = scanner.nextInt();
        if (answer4 == 3) {
            correctAnswers++;
        }

        // Question 5
        System.out.println("Question 5: What is the main benefit of reducing greenhouse gas emissions?");
        System.out.println("1. Increased economic growth");
        System.out.println("2. Improved public health");
        System.out.println("3. Reduced risk of climate change");
        System.out.println("4. Increased energy independence");

        int answer5 = scanner.nextInt();
        if (answer5 == 3) {
            correctAnswers++;
        }

        System.out.println("You answered " + correctAnswers + " questions correctly.");
        if (correctAnswers == 5) {
            System.out.println("Excellent!");
        } else if (correctAnswers == 4) {
            System.out.println("Very good!");
        } else {
            System.out.println("Time to brush up on your knowledge of global warming!");
            System.out.println("Check out these websites for more information:");
            System.out.println("(www.carbonbrief.org)");
            System.out.println("(www.climate.nasa.gov)");
            System.out.println("(www.ourworldindata.org)");
        }
    }
}
