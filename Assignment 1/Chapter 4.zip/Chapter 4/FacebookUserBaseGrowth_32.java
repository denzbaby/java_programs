public class FacebookUserBaseGrowth_32 {
    public static void main(String[] args) {
        double initialUsers = 1e9; // 1 billion initial users
        double growthRate = 0.04; // 4% monthly growth rate
        double targetUsers1 = 1.5e9; // 1.5 billion target users
        double targetUsers2 = 2e9; // 2 billion target users

        int months1 = calculateMonths(initialUsers, growthRate, targetUsers1);
        int months2 = calculateMonths(initialUsers, growthRate, targetUsers2);

        System.out.printf("It will take approximately %d months for Facebook to reach 1.5 billion users.%n", months1);
		
		System.out.printf("It will take approximately %d months for Facebook to reach 2 billion users.%n", months2);
	}
	public static int calculateMonths(double initialUsers,double growthRate,double targetUsers)
	{
		return(int)(Math.log(targetUsers/initialUsers)/Math.log(1 + growthRate));
	}
}	