public class ModifiedCompoundInterest_14 {
    public static void main(String[] args) {
        double principal = 1000.0;
        int years = 10;

        System.out.println("Year\tInterest Rate\tBalance");
        for (double rate = 0.05; rate <= 0.10; rate += 0.01) {
            double balance = principal;
            for (int year = 1; year <= years; year++) {
                balance += balance * rate;
            }
            System.out.printf("%d\t%.2f\t\t$%.2f%n", years, rate * 100, balance);
        }
    }
}
