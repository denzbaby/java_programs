import java.util.Scanner;

public class InputValidator_24 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int input;

        do {
            System.out.print("Enter 1 or 2: ");
            input = scanner.nextInt();
            if (input != 1 && input != 2) {
                System.out.println("Invalid input. Please try again.");
            }
        } while (input != 1 && input != 2);

        System.out.println("Valid input. Thank you!");
    }
}
