import java.util.Scanner;

public class GasMileageCalculator_17 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int totalMiles = 0;
        int totalGallons = 0;
        int tripCount = 0;

        System.out.println("Enter miles driven and gallons used for each trip.");
        System.out.println("Enter -1 for miles driven to quit.");

        while (true) {
            System.out.print("Enter miles driven (-1 to quit): ");
            int milesDriven = scanner.nextInt();

            if (milesDriven == -1) {
                break;
            }

            System.out.print("Enter gallons used: ");
            int gallonsUsed = scanner.nextInt();

            double milesPerGallon = (double) milesDriven / gallonsUsed;
            System.out.printf("Miles per gallon for this trip: %.2f%n", milesPerGallon);

            totalMiles += milesDriven;
            totalGallons += gallonsUsed;
            tripCount++;

            double combinedMilesPerGallon = (double) totalMiles / totalGallons;
            System.out.printf("Combined miles per gallon: %.2f%n%n", combinedMilesPerGallon);
        }

        System.out.println("Summary:");
        System.out.println("Total miles driven: " + totalMiles);
        System.out.println("Total gallons used: " + totalGallons);
        System.out.println("Number of trips: " + tripCount);
        System.out.printf("Combined miles per gallon: %.2f%n", (double) totalMiles / totalGallons);
    }
}
