import java.util.Scanner;

public class CreditLimitChecker_18 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of customers: ");
        int numCustomers = scanner.nextInt();

        for (int i = 0; i < numCustomers; i++) {
            System.out.print("Enter customer's account number: ");
            int accountNumber = scanner.nextInt();

            System.out.print("Enter customer's beginning balance: ");
            int beginningBalance = scanner.nextInt();

            System.out.print("Enter customer's total charges: ");
            int totalCharges = scanner.nextInt();

            System.out.print("Enter customer's total credits: ");
            int totalCredits = scanner.nextInt();

            System.out.print("Enter customer's credit limit: ");
            int creditLimit = scanner.nextInt();

            int newBalance = beginningBalance + totalCharges - totalCredits;

            System.out.printf("Account number: %d%n", accountNumber);
            System.out.printf("New balance: %d%n", newBalance);

            if (newBalance > creditLimit) {
                System.out.println("Credit limit exceeded.");
            }

            System.out.println();
        }
    }
}
