import java.util.Scanner;

public class PopulationGrowthCalculator_39 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the current world population: ");
        double currentPopulation = scanner.nextDouble();
        System.out.print("Enter the current growth rate (in percent): ");
        double growthRate = scanner.nextDouble();

        System.out.println("Year\tPopulation\tIncrease");
        for (int i = 1; i <= 75; i++) {
            double increase = currentPopulation * growthRate / 100;
            currentPopulation += increase;
            System.out.printf("%d\t%,.0f\t%,.0f%n", i, currentPopulation, increase);
        }
    }
}
